import java.util.Scanner;

public class pallindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int rem,num=0;
		 
	     int original=0;
				 
		 
		System.out.println("Enter a no");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		n=original;
		
		
		while(n>0) {
			rem=n%10;
			 num=(num*10)+rem;
			n=n/10;
			
		}
		
		if(original==num) 
			System.out.println("pallindrome");
		
		else
			
			System.out.println("not pallindrome");
		

	}

}
