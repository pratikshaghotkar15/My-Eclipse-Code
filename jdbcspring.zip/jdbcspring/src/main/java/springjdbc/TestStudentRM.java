package springjdbc;
import org.springframework.core.io.ClassPathResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;

public class TestStudentRM {
public static void main(String s[]) {
	int t;
	ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");

  StudentRM objst=(StudentRM)context.getBean("srm");// this beanid is from applicationcontext.xml what we declare in xml we called here
 t= objst.saveStudent(new Student(1250,"kavu dhruv","BCOM"));
 //Student obj2= new Student();
  //obj2.setClassname("btech chemical");
 //obj2.setRollno(1237);
 // t= objst.updateStudent(obj2);
//obj2.setRollno(1250);
//t= objst.delStudent(obj2);

  System.out.println(t);
}
	

}
