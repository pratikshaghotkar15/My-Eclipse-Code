package MyFirstProject;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");

		Employee emp=(Employee)context.getBean("pratiksha1");
		emp.showInfo();
	}

}
