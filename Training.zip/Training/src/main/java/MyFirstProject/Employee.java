package MyFirstProject;

public class Employee {
	private int id;
	private String name;

	public Employee() {
	System.out.println("default constructor");
	
	}
	
	public Employee(int id) {
		super();
		this.id = id;
		System.out.println("first const");
	}
	
	

	public Employee(String name) {
		super();
		this.name = name;
		System.out.println("second const");
	}

	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
		System.out.println("third const");

	}
	
	public void showInfo() {
		System.out.println("Emp id="+id);
		System.out.println("Emp name is="+name);
		
	}
	

}
