package MyFirstProject;

public class Customer {
	
	private int custId;
	private String custName;
	private Address address;
	
	
	
	public Customer() {
		System.out.println("Default constructor");
	}



	public Customer(int custId, String custName, Address address) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.address = address;
	}
	
	public void showData() {
		
		System.out.println("Customer id="+custId);
		System.out.println("Name="+custName);
		System.out.println("Address="+address.toString());
	}
	
	
	
	
	
	
	

}
