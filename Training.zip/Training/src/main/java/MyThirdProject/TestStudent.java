package MyThirdProject;

import java.util.Iterator;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		Criteria objc=session.createCriteria(Student.class);
		
		Student student = new Student();
		
//		student.setRollno(2);
//		student.setClassname("fifth");
//		student.setSname("pratu");
//		session.save(student);
//		System.out.println("successfully saved");
		
//		student.setRollno(2);
//		student.setSname("pratudi");
//		student.setClassname("5fifth");
//		session.update(student);
//        System.out.println("successfullu updated");
//		
//		student.setRollno(2);
//		session.delete(student);
//		System.out.println("suucessfully deleted");
		
		List ls=objc.list();
		System.out.println("Rollno \t Name \t Class Name");
		Iterator itr=ls.iterator();
		while(itr.hasNext()) {
			Student obj=(Student)itr.next();
			System.out.print(obj.getRollno());
			System.out.print("\t"+obj.getSname());
			System.out.println("\t"+obj.getClassname());
		}
		
		tx.commit();
		session.close();
	}

		

	}


