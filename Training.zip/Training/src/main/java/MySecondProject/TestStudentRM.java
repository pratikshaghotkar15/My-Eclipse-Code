package MySecondProject;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class TestStudentRM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int t;
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		
		StudentRM objst=(StudentRM)context.getBean("srm");
		 // for saving data
		//t=objst.saveStudent(new Student(124,"neha"," Bcom"));
		
		//for updating data
		//Student obj=new Student();
		//obj.setClassname("Mcom");
		//obj.setRollno(124);
		//t=objst.updateStudent(obj);
		
		//for delete data
	Student obj=new Student();
	obj.setRollno(124);
	t=objst.delStudent(obj);
//		
		System.out.println(t);

	}

}
