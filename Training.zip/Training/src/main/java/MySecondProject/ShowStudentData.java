package MySecondProject;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ShowStudentData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");

		StudentRM objst=(StudentRM)context.getBean("srm");
		
		List ls = objst.getAllStudents();
		Iterator ir =ls.iterator();
		System.out.println("Rollno\t Student name \t Classname");
		while (ir.hasNext())
		{
			Student st= (Student) ir.next();
			System.out.println(st.getRollno()+"\t"+ st.getSname()+"\t" + st.getClassname());

		}
	}

}
