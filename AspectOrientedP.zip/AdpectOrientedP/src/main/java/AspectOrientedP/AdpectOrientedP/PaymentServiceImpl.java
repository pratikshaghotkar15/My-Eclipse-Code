package AspectOrientedP.AdpectOrientedP;

public class PaymentServiceImpl implements PayemtnService {

	public void makepayment(int amount) {
		// TODO Auto-generated method stub
		System.out.println(amount+"amount debited");
		
		System.out.println(amount+"amount credited");
	}

}
