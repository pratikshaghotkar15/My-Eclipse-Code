package AspectOrientedP.AdpectOrientedP;

public interface PayemtnService {
	public void makepayment(int amount);
		
	

}
