package com.springassignment;

public class Address {
	private String addline1,landmark;
	private int phoneno;
	public Address(String addline1, String landmark, int phoneno) {
		super();
		this.addline1 = addline1;
		this.landmark = landmark;
		this.phoneno = phoneno;
	}
	public String toString()
	{
		return "Address Lin1:"+ addline1+" \nLandmark: "+landmark+"\n Phoneno:- "+phoneno;
	}
	
	
}


