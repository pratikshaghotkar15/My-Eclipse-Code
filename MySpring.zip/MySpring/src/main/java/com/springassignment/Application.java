package com.springassignment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
Student st=(Student) ctx.getBean("stud");
Employee emp=(Employee) ctx.getBean("myemp");
Customer cust=(Customer) ctx.getBean("cust1");
System.out.println(st);
System.out.println(emp);
System.out.println(cust);

Map<Integer,Object> al=new TreeMap<Integer, Object>();
al.put(emp.aadhar,emp);
al.put(cust.aadhar, cust);
al.put(st.aadhar, st);
System.out.println("after Sorting");
for(Integer key:al.keySet())
{
	System.out.println("\naadhar:"+key+"\n Record:"+al.get(key));
}
	}

}
