package com.springassignment;

public class Student {
	private String name;
	private String dob;
	public int aadhar;
	private Address objAdd;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(String name, String dob, int aadhar, Address objAdd) {
		super();
		this.name = name;
		this.dob = dob;
		this.aadhar = aadhar;
		this.objAdd = objAdd;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", dob=" + dob + ", aadhar=" + aadhar + ", objAdd=" + objAdd + "]";
	}
	

}
