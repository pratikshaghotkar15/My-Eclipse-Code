package com.springassignment;

public class Customer {
	private String name;
	private String dob;
	public int aadhar;
	private Address objAdd;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String dob, int aadhar, Address objAdd) {
		super();
		this.name = name;
		this.dob = dob;
		this.aadhar = aadhar;
		this.objAdd = objAdd;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", dob=" + dob + ", aadhar=" + aadhar + ", objAdd=" + objAdd + "]";
	}

}
