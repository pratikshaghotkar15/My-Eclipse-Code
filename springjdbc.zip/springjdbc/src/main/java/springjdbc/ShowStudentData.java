package springjdbc;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ShowStudentData {

	public static void main(String s[])
	{
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");

		StudentRM objst=(StudentRM)context.getBean("srm");// this beanid 
		Student std = new Student();
		std.setClassname("abc");
		std.setRollno(1);
		std.setSname("abcd");
		objst.saveStudent(std);
				List ls = objst.getAllStudents();
		
		Iterator ir =ls.iterator();
		System.out.println("Rollno\t Student name \t Classname");
		while (ir.hasNext())
		{
			Student st= (Student) ir.next();
			System.out.println(st.getRollno()+"\t"+ st.getSname()+"\t" + st.getClassname());

		}
	}
	
}
