package springjdbc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
public class StudentRM {
 private JdbcTemplate jdbctemplate;

public void setJdbctemplate(JdbcTemplate jdbctemplate) {
	this.jdbctemplate = jdbctemplate;
}
 public int saveStudent(Student obj)
 {
	 String query ="insert into student (rollno,sname,classname) values ("+obj.getRollno()+",'"+obj.getSname()+"','"+obj.getClassname()+"')";
	 return jdbctemplate.update(query);
 }
 public int updateStudent(Student obj)
 {
	 String query ="update student set classname='"+obj.getClassname()+"' where rollno="+obj.getRollno();
	 return jdbctemplate.update(query);
	 
 }
 public int delStudent(Student obj) // if no need of object we can pass integer also 
 {
	 String query="delete from student where rollno="+obj.getRollno();
	 return jdbctemplate.update(query);
 }
 public List<Student> getAllStudents()
 {
	 return jdbctemplate.query("select * from student", new ResultSetExtractor <List<Student>>() {
		 
  public List <Student> extractData(ResultSet rs) throws SQLException, DataAccessException{
			List<Student> ls= new ArrayList<Student>(); 
			 while(rs.next())
			 {
				 Student st = new Student();
				 st.setRollno(rs.getInt("rollno"));
				 st.setSname(rs.getString("sname"));
				 st.setClassname(rs.getString("classname"));
				 ls.add(st);
			 }
			return ls;
		 }
		 
	 }   );
	 
 }
}
