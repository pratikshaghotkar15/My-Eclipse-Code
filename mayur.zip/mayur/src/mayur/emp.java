package mayur;
import java.util.*;
class emp1{
	private int eid;
	private String name;
	private int salary;
	public emp1(int eid, String name, int salary) {
		
		this.eid = eid;
		this.name = name;
		this.salary = salary;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "emp1 [eid=" + eid + ", name=" + name + ", salary=" + salary + ", getEid()=" + getEid() + ", getName()="
				+ getName() + ", getSalary()=" + getSalary() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	
}

public class emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<emp1>e1=new ArrayList<emp1>();
		e1.add (new emp1(1,"mayur",40000));
		e1.add (new emp1(2,"raj",50000));
		e1.add (new emp1(3,"patil",80000));
		System.out.println(e1);
		
	Collections.sort(e1,new Mysort());
	System.out.println("after sorting");

	System.out.println(e1);	
	
		

	}

}
class Mysort implements Comparator<emp1>
{

	@Override
	public int compare(emp1 o1, emp1 o2) {
		// TODO Auto-generated method stub
		return (int)(o2.getSalary()-o1.getSalary());
	}
}