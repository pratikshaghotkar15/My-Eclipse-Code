package listquestion;
import org.springframework.core.io.ClassPathResource;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;

public class TestQuestion {
	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
		 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		 Question objq1=(Question)context.getBean("que1");
		// objq1.showQuestion();
		 //int opt1=sc.nextInt();
		objq1.showAnswer();
		// objq1.Askquestion();
		 int opt1=sc.nextInt();
		 if(opt1==1)
		 {
			 System.out.println("the answer is correct");
		 }
		 else
		 {
			 System.out.println("the answer is wrong");

		 }
		 
		 Question objq2=(Question)context.getBean("que2");
		 objq2.showAnswer();
		 int opt2=sc.nextInt();
		 if(opt2==1)
		 {
			 System.out.println("the answer is correct");
		 }
		 else
		 {
			 System.out.println("the answer is wrong");

		 }
		 
		 Question objq3=(Question)context.getBean("que3");
		 objq3.showAnswer();
		 int opt3=sc.nextInt();
		 if(opt3==3)
		 {
			 System.out.println("the answer is correct");
		 }
		 else
		 {
			 System.out.println("the answer is wrong");

		 }
		}


		 
}