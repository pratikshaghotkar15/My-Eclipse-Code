package listquestion;

import java.util.Iterator;
import java.util.List;

public class Question {
	private int id;
	private String name;
	//private List<String> question;
	private List<String> answers;

	/*
	 * public Question(List<String> question, List<String> answers) { this.question
	 * = question; this.answers = answers;
	 * 
	 * }
	 */	
	  public Question(int id, String name, List<String> answers)
	  { 
		  super();
	  	this.id = id; 
	  	this.name = name; 
	  	this.answers = answers;
	  }
	  
		/*
		 * // void showQuestion() { Iterator<String>itr1=question.iterator();
		 * while(itr1.hasNext()) { System.out.println(itr1.next()); } }
		 */


		void showAnswer()
		{ // System.out.println("question id:-"+id); //
			System.out.println("question :-"+name);
			Iterator<String>itr=answers.iterator();
			while(itr.hasNext())
			{ 
				System.out.println(itr.next());
			}
	  
	  }
	 
		/*
		 * public void Askquestion() { Iterator<String>itr1=question.iterator();
		 * while(itr1.hasNext()) { itr1=answers.iterator(); while(itr1.hasNext()) {
		 * System.out.println(itr1.next()); } System.out.println(itr1.next()); }
		 * 
		 * }
		 * 
		 */
		}
