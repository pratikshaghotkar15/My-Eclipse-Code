package com.map;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Certificate {
	@Id
	private int certiId;
	private String certi_Name;
	
	@OneToOne(mappedBy="certi")
	private Person person;
	
	
	public int getCertiId() {
		return certiId;
	}
	public void setCertiId(int certiId) {
		this.certiId = certiId;
	}
	public String getCerti_Name() {
		return certi_Name;
	}
	public void setCerti_Name(String certi_Name) {
		this.certi_Name = certi_Name;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public Certificate() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
