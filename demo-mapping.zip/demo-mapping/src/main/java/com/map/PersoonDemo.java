package com.map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PersoonDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		
		//creating Person 1
				Person p1=new Person();
				p1.setId(567);
				p1.setName("pratiksha ghotkar");
			
		//creating certificate 1
				Certificate certi=new Certificate();
				certi.setCertiId(234);
				certi.setCerti_Name("Coding Certificate");
				certi.setPerson(p1);
				
				p1.setCerti(certi);
				
				//session
				Session s=factory.openSession();
				Transaction tx=s.beginTransaction();
				
				//save
				s.save(p1);
				s.save(certi);
				
				tx.commit();
				
				//fetching
				Person newP=(Person)s.get(Person.class,567);
				System.out.println(newP.getName());
				System.out.println(newP.getCerti().getCerti_Name());
				
				s.close();
				
				factory.close();
			

	}

}
