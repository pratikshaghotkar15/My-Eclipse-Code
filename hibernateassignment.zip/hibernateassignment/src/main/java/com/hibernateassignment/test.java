package  com.hibernateassignment;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class test{

	    public static void main( String[] args )
	    {
	SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	    
	  Session session = sessionFactory.openSession();
	  Transaction t = session.beginTransaction();
	  
	 
	  System.out.println("Enter the choice");
	  System.out.println("1.Add user\n2. Update user\n3.Delete user\n4.Showuser BYID\n5.ShowAllUser");
	  Scanner sc=new Scanner(System.in);
	  int x=sc.nextInt();
	  userdao m=new userdao();
	  switch(x)
	  {
	  	case 1:
	  		{ 
	  			System.out.println(m.AddUser(session,t,x)); 
	  			break;
	  		}
	  	
	  	case 2:
	  	{
		  System.out.println(m.UpdateUser(session, t, x)); 
	  		break;
	  	}
	  	case 3:
  		{ 
  			System.out.println(m.deleteUser(session,t,x)); 
  			break;
  		}
  	
  	case 4:
  	{
  		m.getById(session, t, x); 
  		break;
  	}
  	case 5:
  	{
  		m.getAllUser(session, t, x);
  		break;
  	}
  	
  	default:
  	{
  		System.out.println("wrong choice");
  	}
	  }
	  
		/*
		 * if(x==1) { System.out.println(m.AddUser(session,t,x)); } else if(x==2) {
		 * System.out.println(m.UpdateUser(session, t, x)); } else if(x==3) {
		 * System.out.println(m.deleteUser(session, t, x)); } else if(x==4) {
		 * m.getById(session, t, x);; } else if(x==5) { m.getAllUser(session, t, x); }
		 * else { System.out.println("try again"); }
		 */ 
		
	  }
	
	 
	 
	 
	 
	   


}
