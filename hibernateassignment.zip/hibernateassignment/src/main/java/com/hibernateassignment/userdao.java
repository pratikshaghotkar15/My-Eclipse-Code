package com.hibernateassignment;
import java.util.List;

import java.util.Scanner;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class userdao 
{

		
			Scanner sc=new Scanner(System.in);
			public String AddUser(Session session, Transaction t, int x)
			{
				System.out.println("enter user id");
				int a=sc.nextInt();
				System.out.println("Enter User username");
				String b=sc.next();
				System.out.println("Enter User email");
				String c=sc.next();
				System.out.println("Enter User password");
				String d=sc.next();
				System.out.println("Enter User name");
				String e=sc.next();
				System.out.println("Enter User gender");
				String f=sc.next();
				user s=new user(a,b,c,d,e,f);
				session.save(s);
				t.commit();
				session.close();
				
				return "Record Saved";
				
			}
			public String UpdateUser(Session session, Transaction t, int x)
			{

				System.out.println("Enter Student id");
				int a=sc.nextInt();
				System.out.println("Enter Student username");
				String b=sc.next();
				System.out.println("Enter Student email");
				String c=sc.next();
				System.out.println("Enter Student password");
				String d=sc.next();
				System.out.println("Enter Student name");
				String e=sc.next();
				
				user s = session.get(user.class, a);
				
				s.setId(a);
				s.setUname(b);
				s.setEmail(c);
				s.setPassword(d);
				s.setName(e);
				session.update(s);
				
				t.commit();
				session.close();
				
			
				return "Record Updated";
				
			}
			public String deleteUser(Session session, Transaction t, int x)
			{	
				System.out.println("Enter Student id Which You want to Delete");
				int a=sc.nextInt();
				user s = session.get(user.class, a);
				session.delete(s);
				t.commit();
				session.close();
				
				return"Record is Deleted";
				
			}
			public void getById(Session session, Transaction t, int x)
			{
				System.out.println("Enter Student id");
				int a=sc.nextInt();
				user s = session.get(user.class, a);
				System.out.println("UserId     Username      email      password      name       genader");
				System.out.println(s.getId()+" \t"+s.getUname()+" \t"+s.getEmail()+" \t"+s.getPassword()+" \t"+s.getName()+" \t"+s.getGender());
				session.close();
				
			}
			
			public void getAllUser(Session session, Transaction t, int x)
			{	
				
				 Criteria c = session.createCriteria(user.class);
				List<user> user = c.list();
				System.out.println("UserId  Username  email  password  name   genader");
				for (user s : user) {
					System.out.println(s.getId()+" \t"+s.getUname()+" \t"+s.getEmail()+" \t"+s.getPassword()+" \t"+s.getName()+" \t"+s.getGender());
				}
				session.close();
				
			}
			
			
			
			
			
			

		

	}


