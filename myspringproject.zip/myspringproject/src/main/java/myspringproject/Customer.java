package myspringproject;

public class Customer {
 private Address objAdd;
 private int custid;

private String cname;
 public Customer()
 {
	 System.out.println("Default cons");
 }
 public Customer(Address objAdd, int custid, String cname) 
 {
	super();
	this.objAdd = objAdd;
	this.custid = custid;
	this.cname = cname;
 }
 public void showData()
 {
	 System.out.println("customer name"+cname);
	 System.out.println("customer Id"+custid);
	 System.out.println(objAdd.toString());
 }
 
}
