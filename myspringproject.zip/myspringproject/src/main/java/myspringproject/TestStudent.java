package myspringproject;

import org.springframework.core.io.ClassPathResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;
/**
 *
 * @author vimal.jawla
 */
public class TestStudent {

public static void main(String[] args) {
 //Resource resource=new ClassPathResource("applicationContext.xml");
 //System.out.println(new ClassPathResource("applicationContext.xml").getPath());
 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
//    BeanFactory factory=new XmlBeanFactory(resource);
    Student student=(Student)context.getBean("balrambean");// this beanid is from applicationcontext.xml what we declare in xml we called here
    student.showInfo();
}
}
