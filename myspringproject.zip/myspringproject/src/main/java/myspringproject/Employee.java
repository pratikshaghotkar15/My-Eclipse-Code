package myspringproject;

public class Employee {
	private int empid;
	private String ename;
	public Employee()
	{
		System.out.println("Default consturctor");		
	}
	
	public Employee(int empid) {
		this.empid = empid;		
	}
	public Employee( String ename) {	
		
		this.ename = ename;
	}
	public Employee(int empid, String ename) {
		
		this.empid = empid;
		this.ename = ename;
	}
	public void showemp()
	{
		System.out.println("Empid :- "+ empid);
		System.out.println("name :- "+ ename);
	}
}
