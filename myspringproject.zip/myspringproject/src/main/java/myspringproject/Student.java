package myspringproject;

public class Student {
  private String name;
  int rollno;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getRollno() {
	return rollno;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
  
public void showInfo()
{
  System.out.println("Name of student  "+name);
  System.out.println("Roll no  of studnet  "+rollno);
  
}
	
	
}
