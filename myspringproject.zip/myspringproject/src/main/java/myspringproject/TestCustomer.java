package myspringproject;
	import org.springframework.core.io.ClassPathResource;
	import org.springframework.context.support.ClassPathXmlApplicationContext;
	import org.springframework.core.io.Resource;
	/**
	 *
	 * @author vimal.jawla
	 */
	public class TestCustomer  {

	public static void main(String[] args) {
	 
	 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
	 Customer objc=(Customer)context.getBean("cust");// this beanid is from applicationcontext.xml what we declare in xml we called here
	 objc.showData();
	}
	}


