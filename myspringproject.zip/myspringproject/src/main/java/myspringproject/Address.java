package myspringproject;

public class Address {
		private String addline1,landmark;
		private int phoneno;
		public Address(String addline1, String landmark, int phoneno) {
			super();
			this.addline1 = addline1;
			this.landmark = landmark;
			this.phoneno = phoneno;
		}
		public String toString()
		{
			return "Address Lin1"+ addline1+" Landmark "+landmark+" Phoneno:- "+phoneno;
		}
}
