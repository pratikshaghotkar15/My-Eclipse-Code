package myspringproject;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestQue {
	public static void main(String[] args) {
		 
		 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		 Question objq=(Question)context.getBean("que");
		 // this beanid is from applicationcontext.xml what we declare in xml we called here
		 objq.showAnswer();
			/*
			 * Scanner sc=new Scanner(System.in); System.out.println("enter ur ans"); int
			 * ans1=sc.nextInt();
			 */
		 if(objq.getId()==3) 
		 {
			 System.out.println("the ans is correct");
		 }
		 else
		 {
			 System.out.println("the ans is incorrect");
		 }
		 
		 Question objq2=(Question)context.getBean("que1");
		 objq2.showAnswer();
			/*
			 * System.out.println("enter ur ans"); int ans2=sc.nextInt();
			 */
		 if(objq2.getId()==1)
		 {
			 System.out.println("ans is correct");
		 }
		 else
			 System.out.println("ans is incorrect");
		 
		}
}
