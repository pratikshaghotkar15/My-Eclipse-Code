package myspringproject;




import org.springframework.core.io.ClassPathResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;
/**
 *
 * @author vimal.jawla
 */
public class TestEmp {

public static void main(String[] args) {
 
 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
 Employee e=(Employee)context.getBean("myemp");// this beanid is from applicationcontext.xml what we declare in xml we called here
 e.showemp();
}
}

