package com.assignment;

public class Employee extends BaseObject{
	
	public Employee(String name, String address, int adharno, String date) {
		super(name, address, adharno, date);
	}

	@Override
	public String toString() {
		return "Employee [getName()=" + getName() + ", getAddress()=" + getAddress() + ", getAdharno()=" + getAdharno()
				+ ", getDate()=" + getDate() + "]";
	}
	
	

}
