package com.assignment;

public class Customer extends BaseObject{

	public Customer(String name, String address, int adharno, String date) {
		super(name, address, adharno, date);
		
		
	}

	@Override
	public String toString() {
		return "Customer [getName()=" + getName() + ", getAddress()=" + getAddress() + ", getAdharno()=" + getAdharno()
				+ ", getDate()=" + getDate() +  "]";
				
	}

}
