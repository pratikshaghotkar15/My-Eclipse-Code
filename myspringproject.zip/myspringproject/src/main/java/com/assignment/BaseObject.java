package com.assignment;

import java.util.Date;

public class BaseObject {
	private String name;
	private String address;
	private int adharno;
	private String date;

	public BaseObject(String name, String address, int adharno, String date) {
		super();
		this.name = name;
		this.address = address;
		this.adharno = adharno;
		this.date = date;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAdharno() {
		return adharno;
	}

	public void setAdharno(int adharno) {
		this.adharno = adharno;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
