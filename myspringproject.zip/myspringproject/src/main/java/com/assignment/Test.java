package com.assignment;

import java.util.Map;
import java.util.TreeMap;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
//	    BeanFactory factory=new XmlBeanFactory(resource);
	    Employee employee=(Employee)context.getBean("employee");// this beanid is from applicationcontext.xml what we declare in xml we called here
	   System.out.println(employee.toString());
	   
	   
	   Customer customer=(Customer)context.getBean("customer");
	   System.out.println(customer.toString());
	   
	   Map<Integer,Object> al=new TreeMap<Integer, Object>();
	   al.put(employee.getAdharno(),employee);
	   al.put(customer.getAdharno(), customer);
	   
	   System.out.println("after Sorting");
	   for(Integer key:al.keySet())
	   {
	   	System.out.println("\naadhar:"+key+"\n Record:"+al.get(key));
	   }
	   	}

	
}
