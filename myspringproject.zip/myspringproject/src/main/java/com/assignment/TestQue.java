package com.assignment;
import java.util.Scanner;


import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestQue {
	public static void main(String[] args) {
		 
		 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		 Question objq=(Question)context.getBean("mcq");
		 // this beanid is from applicationcontext.xml what we declare in xml we called here
		 objq.showAnswer();
			System.out.println();
			System.out.println("enter a ans");
	
	 Scanner sc=new Scanner(System.in);
		 int opt1=sc.nextInt();
		 if(opt1==1) 
		 {
			 System.out.println("the ans is correct");
		 }
		 else
		 {
			 System.out.println("the ans is incorrect");
		 }
		 
		 Question objq2=(Question)context.getBean("mcq1");
		 objq2.showAnswer();
		 System.out.println();
		 System.out.println("enter a ans");
			
			int opt2=sc.nextInt();
		 if(opt2==2)
		 {
			 System.out.println("ans is correct");
		 }
		 else
			 System.out.println("ans is incorrect");
		 
		}
}
