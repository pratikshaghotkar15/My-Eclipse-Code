package autowiredemo;

public class Demo {
int a, b , c;
float d,e;
String name,address;
public int getA() {
	return a;
}

public void setA(int a) {
	this.a = a;
}
public int getB() {
	return b;
}
public void setB(int b) {
	this.b = b;
}
public int getC() {
	return c;
}
public void setC(int c) {
	this.c = c;
}
public float getD() {
	return d;
}
public void setD(float d) {
	this.d = d;
}
public float getE() {
	return e;
}
public void setE(float e) {
	this.e = e;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

}
