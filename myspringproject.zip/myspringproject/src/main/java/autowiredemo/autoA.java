package autowiredemo;

public class autoA {
 
		private autoW1 b;
		autoA(){
			System.out.println(" autoA �is�created");
		}
		public autoW1 getB() {
		 return b;
		}
		public void setB(autoW1 obj) {
			
			this.b = obj; 
		} 
	public	void print()
		{
			 System.out.println("hello�autoA");
		} 
	public void display()
	{
		print();		
		b.print();
	}
} 