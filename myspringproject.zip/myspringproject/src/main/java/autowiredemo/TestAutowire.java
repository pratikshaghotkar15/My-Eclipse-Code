package autowiredemo;
import org.springframework.core.io.ClassPathResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;

import myspringproject.Employee;
public class TestAutowire {
public static void main(String s[])
{

	 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
	 autoA objA=(autoA)context.getBean("a");
	 // this beanid is from applicationcontext.xml what we declare in xml we called here
	 objA.display();
}

}
