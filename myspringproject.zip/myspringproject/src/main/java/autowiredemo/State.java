package autowiredemo;

public class State {
	State()
	{
		System.out.println("State cons called");
	}
	void printState()
	{
		System.out.println("MP");
	}
}
