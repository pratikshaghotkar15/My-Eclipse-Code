package autowiredemo;
import org.springframework.core.io.ClassPathResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.Resource;


public class TestCons {
public static void main(String s[])
{

	 ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
	 City objC=(City)context.getBean("c");
	 // this beanid is from applicationcontext.xml what we declare in xml we called here
	 objC.printCityState();
}
}
