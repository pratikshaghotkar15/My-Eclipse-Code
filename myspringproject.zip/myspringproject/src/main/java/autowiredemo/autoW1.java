package autowiredemo;

public class autoW1 {
   
	autoW1()
	{
		 System.out.println(" autow1 �is�created");
    }
  public void print(){
	   System.out.println("hello�autow1 ");
	  }	
}

