package autowiredemo;

public class City {
private String cname;
private State objst;
	
	public City(String cname, State objst)
	{
	this.cname = cname;
	this.objst = objst;
	System.out.println("City constructor called");
	}
	
	void printCityState()
	{
	System.out.println("Name of city:-"+cname);
	System.out.println("City to belong to state");
	objst.printState();
	}
}
