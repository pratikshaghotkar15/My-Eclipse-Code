package com.springjdbcassignment;

public class item {

	private int itemid;
	private String itemname;
	private float price;
	private int catid;
	public item(int itemid, String itemname, float price, int catid) {
		super();
		this.itemid = itemid;
		this.itemname = itemname;
		this.price = price;
		this.catid = catid;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	
	
	
}
