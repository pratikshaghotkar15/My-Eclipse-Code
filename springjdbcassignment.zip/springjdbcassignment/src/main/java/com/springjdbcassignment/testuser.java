package com.springjdbcassignment;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class testuser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");

		  userdao objst=(userdao)context.getBean("srm");
		System.out.println("Enter the choice");
		  System.out.println("1.Add user\n2. Update user\n3.Delete user");
		  Scanner sc=new Scanner(System.in);
		  int x=sc.nextInt();
		  userdao m=new userdao();
		  user u=new user();
		  switch(x)
		  {
		  	case 1:
		  		{ 
		  			System.out.println(m.saveuser(u)); 
		  			break;
		  		}
		  	
		  	case 2:
		  	{
			  System.out.println(m.updateuser(u)); 
		  		break;
		  	}
		  	case 3:
	  		{ 
	  			System.out.println(m.deluser(u)); 
	  			break;
	  		}
	  	
	  	
	  	
	  	default:
	  	{
	  		System.out.println("wrong choice");
	  	}
		  }
		  

	}

}
