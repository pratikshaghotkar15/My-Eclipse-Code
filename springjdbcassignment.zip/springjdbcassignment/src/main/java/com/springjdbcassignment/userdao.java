package com.springjdbcassignment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public class userdao {
	
	 private JdbcTemplate jdbctemplate;
	 Scanner sc=new Scanner(System.in);

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	 public int saveuser(user u1)
	 {
		 System.out.println("enter user id");
			int a=sc.nextInt();
			System.out.println("Enter username");
			String b=sc.next();
			System.out.println("Enter useraddress");
			String c=sc.next();
			
			String query ="insert into user (rollno,name,address) values ("+u1.getId()+",'"+u1.getName()+"','"+u1.getAddress()+"')";
			
		 return jdbctemplate.update(query);
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	 
	 
	 
	 public int updateuser(user obj)
	 {
		 String query ="update user set address='"+obj.getAddress()+"' where id="+obj.getId();
		 return jdbctemplate.update(query);
		 
	 }
	 public int deluser(user obj) // if no need of object we can pass integer also 
	 {
		 String query="delete from user where id="+obj.getId();
		 return jdbctemplate.update(query);
	 }
	 public List<user> getAllStudents()
	 {
		 return jdbctemplate.query("select * from user", new ResultSetExtractor <List<user>>() {
			 
	  public List <user> extractData(ResultSet rs) throws SQLException, DataAccessException{
				List<user> ls= new ArrayList<user>(); 
				 while(rs.next())
				 {
					 user us=new user();
					 us.setId(rs.getInt("id"));
					 us.setName(rs.getString("name"));
					 us.setAddress(rs.getString("address"));
					 ls.add(us);
					 
					
				 }
				return ls;
			 }
			 
		 }   );
		 
	 }
	}


