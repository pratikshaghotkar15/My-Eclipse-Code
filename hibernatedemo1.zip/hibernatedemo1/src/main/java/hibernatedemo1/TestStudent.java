package hibernatedemo1;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class TestStudent {
	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;
	private static Session session;
	public static void main(String[] args) {

		try {
			// Create registry
			registry = new StandardServiceRegistryBuilder().configure().build();

			// Create MetadataSources
			MetadataSources sources = new MetadataSources(registry);

			// Create Metadata
			Metadata metadata = sources.getMetadataBuilder().build();

			// Create SessionFactory
			sessionFactory = metadata.getSessionFactoryBuilder().build();
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();

			//Student s = session.get(Student.class, 101);
			Student s=new Student();
			
			s.setSname("neha");
			s.setClassname("Bed");
            session.save(s);    
			//session.update(s);
			transaction.commit();
			
			System.out.println("successfully saved");
			//System.out.println("successfully updated");
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			session.close();
			sessionFactory.close();
		}
	}
}